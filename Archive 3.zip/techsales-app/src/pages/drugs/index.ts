export { DrugSearchPage } from './DrugSearch';

